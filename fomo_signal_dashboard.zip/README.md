# FOMO Signal Dashboard

Phone-first hosted version of the Solana micro-cap scanner.

## What you get
- Live responsive dashboard
- STRONG WATCH / WATCH cards
- liquidity, buyers, buy/sell flow, price move, volume acceleration, drawdown
- top-10, bundler, sniper, insider and dev concentration
- Copy CA button
- FOMO web shortcut
- installable to iPhone Home Screen

## Deploy to Render (phone-friendly route)

1. Put these files in a GitHub repository.
2. In Render choose **New → Web Service** and connect the repo.
3. Use Docker runtime (the included Dockerfile handles build/start).
4. Add environment variable `BIRDEYE_API_KEY` with your Birdeye Data API key.
5. Use an always-on paid instance if you want continuous scanning. Free Render web
   services can spin down when idle, which is not ideal for a live scanner.
6. Open the generated `onrender.com` URL on iPhone Safari.
7. Share → Add to Home Screen.

Never put API keys in the repository.

## Notes
- This app NEVER places trades.
- Signals are relative screening results, not guarantees or a claim of safety.
- Birdeye endpoint/WebSocket access depends on your Birdeye API package.
- The FOMO button opens FOMO web; the dashboard also exposes Copy CA so you can
  paste the exact contract into FOMO search.
