
"""
Scanner core.
Uses Birdeye for live Solana pair discovery and short confirmation windows.
Research alerts only; it never places a trade.
"""
import os, json, time, asyncio, sqlite3
from typing import Any, Dict, List, Optional
import requests, websockets

API_KEY = os.getenv("BIRDEYE_API_KEY", "").strip()
REST = "https://public-api.birdeye.so"
WS = f"wss://public-api.birdeye.so/socket/solana?x-api-key={API_KEY}"
HEADERS = {"X-API-KEY": API_KEY, "x-chain": "solana", "accept": "application/json"}

MIN_LIQ = float(os.getenv("MIN_LIQUIDITY", "10000"))
MAX_LIQ = float(os.getenv("MAX_LIQUIDITY", "100000"))
STRUCTURE_MIN = int(os.getenv("STRUCTURE_MIN_SCORE", "70"))
FINAL_WATCH = int(os.getenv("FINAL_WATCH_SCORE", "76"))
FINAL_STRONG = int(os.getenv("FINAL_STRONG_SCORE", "86"))
CONFIRM_SECONDS = int(os.getenv("CONFIRM_SECONDS", "75"))
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "15"))

def _data(x):
    return x.get("data", x) if isinstance(x, dict) else x

def _num(v, default=0.0):
    try: return float(v) if v is not None else default
    except: return default

def _pick(d, *keys, default=None):
    if not isinstance(d, dict): return default
    for k in keys:
        if k in d and d[k] is not None: return d[k]
    return default

def get_json(path, params):
    r = requests.get(REST + path, params=params, headers=HEADERS, timeout=12)
    r.raise_for_status()
    return r.json()

def security(address):
    return _data(get_json("/defi/token_security", {"address": address})) or {}

def holder_profile(address):
    return _data(get_json("/token/v1/holder-profile", {
        "address": address, "include_zero_balance": "false", "ui_amount_mode": "scaled"
    })) or {}

def recent_trades(address):
    d = _data(get_json("/defi/v3/token/txs", {
        "address": address, "limit": 100, "offset": 0, "tx_type": "all",
        "after_time": int(time.time())-120, "ui_amount_mode": "scaled"
    }))
    if isinstance(d, list): return d
    if isinstance(d, dict):
        for k in ("items","list","txs","transactions"):
            if isinstance(d.get(k), list): return d[k]
    return []

def candles(address):
    d = _data(get_json("/defi/v3/ohlcv", {
        "address": address, "type": "15s", "mode": "count",
        "count_limit": 12, "ui_amount_mode": "scaled"
    }))
    if isinstance(d, list): return d
    if isinstance(d, dict):
        for k in ("items","list","candles"):
            if isinstance(d.get(k), list): return d[k]
    return []

def find_tag(profile, tag):
    tag = tag.lower()
    stack = [profile]
    seen = 0
    while stack and seen < 250:
        cur = stack.pop(); seen += 1
        if not isinstance(cur, dict): continue
        if str(_pick(cur,"tag","name","type",default="")).lower() == tag:
            return cur
        for k,v in cur.items():
            if str(k).lower() == tag and isinstance(v, dict): return v
            if isinstance(v, dict): stack.append(v)
            elif isinstance(v, list): stack += [x for x in v if isinstance(x, dict)]
    return {}

def pct_tag(p, tag):
    d = find_tag(p, tag)
    x = _num(_pick(d, "percentOfSupply","percent_of_supply","supplyPercent",
                   "supply_percent","percentage","percent","pct",default=0))
    return x*100 if 0 < x <= 1 else x

def top10(p):
    stack=[p]
    for c in stack + [p.get(k,{}) for k in ("holderSummary","holder_summary","summary")]:
        x = _pick(c, "top10HolderPercent","top10_holder_percent","top10Percentage",
                  "top10_percentage","top10HolderPercentage",default=None)
        if x is not None:
            x=_num(x); return x*100 if 0 < x <= 1 else x
    return 0

def secflag(sec, names):
    places=[sec] + [v for v in sec.values() if isinstance(v,dict)]
    for place in places:
        for n in names:
            if n in place:
                v=place[n]
                if isinstance(v,bool): return v
                if isinstance(v,(int,float)): return bool(v)
                s=str(v).lower()
                if s in ("true","yes","1","active","enabled"): return True
                if s in ("false","no","0","inactive","disabled","null","none",""): return False
    return None

def structural(address, liq):
    score=100; reasons=[]; hard=False
    if liq < MIN_LIQ: score-=45; reasons.append("liquidity below floor")
    elif liq < 15000: score-=10; reasons.append("thin liquidity")
    else: reasons.append(f"${liq:,.0f} liquidity")

    try: sec=security(address)
    except: sec={}; score-=10; reasons.append("security data unavailable")

    if secflag(sec,["honeypot","isHoneypot","is_honeypot"]) is True:
        score-=80; hard=True; reasons.append("honeypot warning")
    if secflag(sec,["fakeToken","fake_token","isFakeToken"]) is True:
        score-=80; hard=True; reasons.append("fake-token warning")
    if secflag(sec,["freezeable","freezeAuthority","freeze_authority","isFreezeable"]) is True:
        score-=25; reasons.append("freeze risk")
    if secflag(sec,["mintable","mintAuthority","mint_authority","isMintable"]) is True:
        score-=20; reasons.append("mint risk")

    try: hp=holder_profile(address)
    except: hp={}; score-=10; reasons.append("holder profile unavailable")

    vals={"top10_pct":top10(hp),"bundler_pct":pct_tag(hp,"bundler"),
          "sniper_pct":pct_tag(hp,"sniper"),"insider_pct":pct_tag(hp,"insider"),
          "dev_pct":pct_tag(hp,"dev")}
    checks=[
      ("top10_pct","top10",35,50,12,30),
      ("bundler_pct","bundlers",10,20,15,35),
      ("sniper_pct","snipers",10,20,15,35),
      ("insider_pct","insiders",8,15,18,40),
      ("dev_pct","dev",5,10,18,40),
    ]
    for key,label,soft,hardv,sp,hpnt in checks:
        v=vals[key]
        if v>=hardv: score-=hpnt; hard=True; reasons.append(f"{label} {v:.1f}% HIGH")
        elif v>=soft: score-=sp; reasons.append(f"{label} {v:.1f}%")
        elif v>0: reasons.append(f"{label} {v:.1f}%")
    return max(0,min(100,int(score))),hard,vals,reasons

def side(tx):
    s=str(_pick(tx,"side","txType","tx_type","type",default="")).lower()
    return "buy" if "buy" in s else "sell" if "sell" in s else ""

def owner(tx):
    return str(_pick(tx,"owner","wallet","trader","user",default=""))

def usd(tx):
    return abs(_num(_pick(tx,"volumeUSD","volumeUsd","volume_usd","valueUsd",
                          "value_usd","amountUsd","amount_usd",default=0)))

def momentum(address):
    try: txs=recent_trades(address)
    except: txs=[]
    buys=[]; sells=[]; buyusd=0; sellusd=0
    for tx in txs:
        s=side(tx); w=owner(tx); v=usd(tx)
        if s=="buy": buys.append(w or f"b{len(buys)}"); buyusd+=v
        elif s=="sell": sells.append(w or f"s{len(sells)}"); sellusd+=v

    ub=len(set(buys)); us=len(set(sells)); trades=len(buys)+len(sells)
    ratio=buyusd/max(sellusd,1)

    try: raw=candles(address)
    except: raw=[]
    cs=[]
    for c in raw:
        ts=int(_num(_pick(c,"unixTime","unix_time","time","timestamp",default=0)))
        close=_num(_pick(c,"c","close","scaledC",default=0))
        high=_num(_pick(c,"h","high","scaledH",default=close))
        vol=_num(_pick(c,"vUsd","v_usd","volumeUsd","volume_usd","scaledV","v",default=0))
        if close>0: cs.append((ts,close,high,vol))
    cs.sort()
    pchg=0; dd=0; vacc=1
    if len(cs)>=2:
        pchg=(cs[-1][1]/cs[0][1]-1)*100 if cs[0][1] else 0
        peak=max(x[2] for x in cs); dd=max(0,(peak-cs[-1][1])/peak*100) if peak else 0
        if len(cs)>=4:
            vacc=sum(x[3] for x in cs[-2:])/max(sum(x[3] for x in cs[-4:-2]),1)

    score=50; reasons=[]
    score += 8 if trades>=8 else -15
    reasons.append(f"{trades} trades")
    score += 12 if ub>=5 else -15
    reasons.append(f"{ub} unique buyers")
    if 1.1<=ratio<=5: score+=10
    elif ratio>5: score-=6
    else: score-=15
    reasons.append(f"buy/sell {ratio:.2f}x")
    if 2<=pchg<=45: score+=12
    elif pchg>45: score-=18
    elif pchg<-5: score-=20
    reasons.append(f"price {pchg:+.1f}%")
    if vacc>=1.5: score+=10
    elif vacc<0.65: score-=10
    reasons.append(f"volume {vacc:.2f}x")
    if dd<=8: score+=8
    elif dd>=18: score-=22
    else: score-=5
    reasons.append(f"drawdown {dd:.1f}%")
    if buys:
        div=ub/len(buys)
        if div>=.55: score+=5
        elif div<.30: score-=10

    return {
      "score":max(0,min(100,int(score))),"trades":trades,
      "unique_buyers":ub,"unique_sellers":us,"buy_usd":buyusd,"sell_usd":sellusd,
      "buy_sell_ratio":ratio,"price_change_pct":pchg,"drawdown_pct":dd,
      "volume_acceleration":vacc,"reasons":reasons
    }

def save(db_path, item):
    con=sqlite3.connect(db_path)
    con.execute("""insert into signals(
      ts,address,symbol,name,liquidity,structure_score,momentum_score,final_score,verdict,
      top10_pct,bundler_pct,sniper_pct,insider_pct,dev_pct,trades,unique_buyers,unique_sellers,
      buy_usd,sell_usd,buy_sell_ratio,price_change_pct,drawdown_pct,volume_acceleration,reasons
      ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
      (int(time.time()),item["address"],item["symbol"],item["name"],item["liquidity"],
       item["structure_score"],item["momentum_score"],item["final_score"],item["verdict"],
       item["top10_pct"],item["bundler_pct"],item["sniper_pct"],item["insider_pct"],item["dev_pct"],
       item["trades"],item["unique_buyers"],item["unique_sellers"],item["buy_usd"],item["sell_usd"],
       item["buy_sell_ratio"],item["price_change_pct"],item["drawdown_pct"],
       item["volume_acceleration"],json.dumps(item["reasons"])))
    con.commit(); con.close()

async def confirm(db_path,address,symbol,name,liq,s_score,vals,s_reasons):
    await asyncio.sleep(15)
    started=time.time(); latest=None
    while time.time()-started < CONFIRM_SECONDS:
        latest=await asyncio.to_thread(momentum,address)
        await asyncio.sleep(POLL_SECONDS)
    latest=latest or momentum(address)
    final=round(s_score*.58 + latest["score"]*.42)
    hard_m=latest["price_change_pct"]>45 or latest["drawdown_pct"]>=18 or (
        latest["trades"]>=8 and latest["buy_sell_ratio"]<.70)
    verdict="PASS" if hard_m else "STRONG WATCH" if final>=FINAL_STRONG else "WATCH" if final>=FINAL_WATCH else "PASS"
    if verdict=="PASS": return
    item={"address":address,"symbol":symbol,"name":name,"liquidity":liq,
          "structure_score":s_score,"momentum_score":latest["score"],"final_score":final,
          "verdict":verdict,**vals,**{k:v for k,v in latest.items() if k not in ("score","reasons")},
          "reasons":s_reasons+latest["reasons"]}
    save(db_path,item)

async def run_scanner(db_path):
    seen=set()
    headers={"Origin":"ws://public-api.birdeye.so","Sec-WebSocket-Origin":"ws://public-api.birdeye.so",
             "Sec-WebSocket-Protocol":"echo-protocol"}
    while True:
        try:
            async with websockets.connect(WS,additional_headers=headers,
                subprotocols=["echo-protocol"],ping_interval=20,ping_timeout=20) as ws:
                await ws.send(json.dumps({"type":"SUBSCRIBE_NEW_PAIR",
                    "min_liquidity":MIN_LIQ,"max_liquidity":MAX_LIQ}))
                async for raw in ws:
                    try: m=json.loads(raw); d=m.get("data",m)
                    except: continue
                    if not isinstance(d,dict): continue
                    addr=_pick(d,"baseAddress","base_address","tokenAddress","token_address",
                               "address","baseTokenAddress",default="")
                    if not addr or addr in seen: continue
                    seen.add(addr)
                    symbol=str(_pick(d,"symbol","baseSymbol","base_symbol",default="?"))
                    name=str(_pick(d,"name","baseName","base_name",default="?"))
                    liq=_num(_pick(d,"liquidity","liquidityUsd","liquidity_usd",default=0))
                    if liq and not MIN_LIQ<=liq<=MAX_LIQ: continue
                    s_score,hard,vals,reasons=await asyncio.to_thread(structural,addr,liq)
                    if hard or s_score<STRUCTURE_MIN: continue
                    asyncio.create_task(confirm(db_path,addr,symbol,name,liq,s_score,vals,reasons))
        except Exception:
            await asyncio.sleep(4)
