
import os, json, time, asyncio, sqlite3
from pathlib import Path
from typing import Dict, Any, List

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).parent
DB = APP_DIR / "signals.db"

app = FastAPI(title="FOMO Signal Scanner")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    con = db()
    con.execute("""
    create table if not exists signals (
      id integer primary key autoincrement,
      ts integer not null,
      address text not null,
      symbol text,
      name text,
      liquidity real,
      structure_score integer,
      momentum_score integer,
      final_score integer,
      verdict text,
      top10_pct real,
      bundler_pct real,
      sniper_pct real,
      insider_pct real,
      dev_pct real,
      trades integer,
      unique_buyers integer,
      unique_sellers integer,
      buy_usd real,
      sell_usd real,
      buy_sell_ratio real,
      price_change_pct real,
      drawdown_pct real,
      volume_acceleration real,
      reasons text
    )
    """)
    con.commit()
    con.close()

@app.on_event("startup")
async def startup():
    init_db()
    # Background scanner is optional until a Birdeye key is added.
    if os.getenv("BIRDEYE_API_KEY"):
        from scanner_core import run_scanner
        asyncio.create_task(run_scanner(DB))

@app.get("/", response_class=HTMLResponse)
def home():
    return (APP_DIR/"static"/"index.html").read_text(encoding="utf-8")

@app.get("/api/signals")
def signals(limit: int = 100):
    con = db()
    rows = con.execute(
        "select * from signals order by ts desc limit ?", (max(1, min(limit, 250)),)
    ).fetchall()
    con.close()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["reasons"] = json.loads(d["reasons"] or "[]")
        except Exception:
            d["reasons"] = []
        out.append(d)
    return JSONResponse(out)

@app.get("/api/status")
def status():
    return {
        "scanner_enabled": bool(os.getenv("BIRDEYE_API_KEY")),
        "server_time": int(time.time()),
        "mode": "live" if os.getenv("BIRDEYE_API_KEY") else "demo/setup"
    }
